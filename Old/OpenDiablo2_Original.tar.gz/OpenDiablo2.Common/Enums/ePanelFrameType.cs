﻿namespace OpenDiablo2.Common.Enums
{
    public enum ePanelFrameType
    {
        Left,
        Right,
        Center
    }
}
