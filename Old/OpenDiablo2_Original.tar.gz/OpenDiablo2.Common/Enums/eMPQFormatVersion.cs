﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenDiablo2.Common.Enums
{
    public enum eMPQFormatVersion
    {
        Format1,
        Format2,
        Format3,
        Format4
    }
}
