﻿namespace OpenDiablo2.Common.Enums
{
    public enum eMovementType
    {
        Stopped,
        Walking,
        Running
    }
}
