﻿namespace OpenDiablo2.Common.Enums
{
    public enum eTextAlign
    {
        Centered = 0,
        Left,
        Right
    }
}
