﻿using System.Collections.Generic;

namespace OpenDiablo2.Common.Enums
{
    public enum eItemContainerType
    {
        Helm,
        Glove,
        Armor,
        Belt,
        Boots,
        Weapon,
        Amulet,
        Ring,
        Generic
    }
}