﻿namespace OpenDiablo2.Common.Enums
{
    public enum ePanelType
    {
        None,
        Character,
        Inventory,
        Skill,
        Automap,
        Message,
        Quest,
        Menu
    }
}
