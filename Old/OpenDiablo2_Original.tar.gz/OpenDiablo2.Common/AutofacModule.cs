﻿/*
 *  Hi there.
 *  Looking to register an object from Common into DI, are ya?
 *  Well don't. Go to the Discord channel and talk about it there.
 *  If you add an autofac module to this project, your PR will be
 *  rejected.
 */