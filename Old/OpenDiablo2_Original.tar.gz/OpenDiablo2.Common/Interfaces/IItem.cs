﻿using System;

namespace OpenDiablo2.Common.Interfaces
{
    public interface IItem
    {
        string Name { get; set; }
        string Code { get; set; }
    }
}
