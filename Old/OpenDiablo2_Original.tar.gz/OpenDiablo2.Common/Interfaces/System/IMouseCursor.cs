﻿namespace OpenDiablo2.Common.Interfaces
{
    /// <summary>A cursor that can be displayed on the screen to indicate the location of the mouse.</summary>
    public interface IMouseCursor { }
}
