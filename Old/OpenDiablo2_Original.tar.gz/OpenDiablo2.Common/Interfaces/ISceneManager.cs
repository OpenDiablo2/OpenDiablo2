﻿using OpenDiablo2.Common.Enums;

namespace OpenDiablo2.Common.Interfaces
{
    public interface ISceneManager
    {
        void ChangeScene(eSceneType sceneType);
    }
}
