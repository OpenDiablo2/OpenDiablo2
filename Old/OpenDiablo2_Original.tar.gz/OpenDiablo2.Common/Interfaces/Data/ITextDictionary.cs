﻿namespace OpenDiablo2.Common.Interfaces
{
    public interface ITextDictionary
    {
        string Translate(string key);
    }
}
